from django.db import models

# Create your models here.
class stock(models.Model):
    open=models.FloatField()
    high=models.FloatField()
    low=models.FloatField()
    last=models.FloatField()
    close=models.FloatField()
    trade=models.FloatField()