from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
import pandas as pd
from sklearn.tree import DecisionTreeRegressor
from .models import stock
# Create your views here.
def index(request):
    return render(request,"index.html")
def about(request):
    return render(request,"about.html")
def how(request):
    return render(request,"how.html")
def register(request):
    if request.method=="POST":
        un=request.POST['name'] #username
        em=request.POST['email'] #email
        pd=request.POST['pass']
        pd2=request.POST['re_pass']

        user=User.objects.create_user(username=un,email=em,password=pd)
        user.save()
        return redirect('login')
    else:
        return render(request,"register.html")

def login(request):
    if request.method=="POST":
        ps=request.POST['your_pass']
        ur=request.POST['your_name']
        user=auth.authenticate(username=ur,password=ps)
        if user is not None:
            auth.login(request,user)
            return redirect("index")
        else:
            messages.info(request,"Invalid Creds !")
            return render(request,"register.html")
    return render(request,"login.html")

def logout(request):
    auth.logout(request)
    return redirect("index")
def forms(request):
    return render(request,"forms.html")
def stockpredict(request):
    if (request.method == 'POST'):
        open = request.POST['open']
        high = request.POST['high']
        low= request.POST['low']
        last = request.POST['last']
        close = request.POST['close']
        trade=request.POST['trade']

        df = pd.read_csv(r"static/datasets/Stock.csv")
        df.dropna(inplace=True)
        df.isnull().sum()

        import matplotlib.pyplot as plt
        plt.title('Stock Market Data')
        plt.xlabel('Last')
        plt.ylabel('Turnover (Lacs)')
        plt.scatter(df['Last'],df['Turnover (Lacs)'])
        plt.show()
        plt.title('Stock Market Data')
        plt.xlabel('Open')
        plt.ylabel('Close')
        plt.bar(df['Open'],df['Close'])
        plt.show()
        plt.title('Stock Market Data')
        plt.xlabel('Last')
        plt.ylabel('Turnover (Lacs)')
        plt.plot(df['Last'],df['Turnover (Lacs)'])
        plt.show()


        X_train = df[['Open','High','Low','Last','Close','Total_Trade_Quantity']]
        Y_train = df[['Turnover (Lacs)']]
        from sklearn.ensemble import RandomForestClassifier
        tree=DecisionTreeRegressor()
        ran=RandomForestClassifier()
        tree.fit(X_train, Y_train)
        
        
        prediction = tree.predict([[open,high,low,last,close,trade]])

        stockk=stock.objects.create(open=open,last=last,high=high,low=low,close=close,trade=trade)
        stockk.save()
        return render(request, 'stockpredict.html',
                      {'prediction': prediction, 'open': open,  'high': high,
                       'close': close, 'last': last,"low":low,'trade':trade})
    else:
        return render(request, 'stockpredict.html')




